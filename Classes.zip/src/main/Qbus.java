package main;

import java.util.ArrayList;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import qbus2.QbusProducer;

public class Qbus implements Session{

	/* 
	 * qbus ���
	 */
	private KafkaProducer<String, String> qbus;
	
	private String conf_file;
	
	private ArrayList<String> topics;
	
	private String cluster;
	
	
	public Qbus(String cluster, String conf_file, ArrayList<String> topics)
	{		
		this.cluster = cluster;
		this.conf_file = conf_file;
		this.topics = topics;
	}
	
	public void conn() throws Exception 
	{
		qbus = new QbusProducer<String, String>(cluster, conf_file, topics).getProducer();
	}
	
	public void close() throws Exception 
	{
		qbus.close();
	}
	
	public void send(String msg) throws Exception 
	{
		qbus.send(new ProducerRecord<String, String>("mytopic", null, msg));
	}

	public String recv() throws Exception
	{
		// nothing to do
		throw new Exception("Qbus::recv() should not be called");
	}

	public void ack() throws Exception {
		// nothing to do
		throw new Exception("Qbus::ack() should not be called");
	}
	
}
