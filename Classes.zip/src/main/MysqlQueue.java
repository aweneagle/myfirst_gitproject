package main;
import java.util.ArrayList;

import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;  

public class MysqlQueue {
	
	private boolean stop;

	private Logger logger;
	
	public void Start()
	{
		logger = LoggerFactory.getLogger(MysqlQueue.class);
    	Thread th = new Thread( new Runnable(){
			public void run() {
				process();
			}
    	});
    	th.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                logger.error("parse events has an error" + e.getMessage());
            }
        });
    	th.start();
	}
	
	/*
	 * Start() ��������
	 */
	public void process()
	{
		/*
		 * ׼���� qbus ���ã� ������ qbus
		 */
		ArrayList<String> topics = new ArrayList<String>();
		topics.add("fortest");
		SafeService qbus = new SafeService(
				new Qbus("os_zt_mysql_bin_log", "./mysql_bin_log.protities", topics),
				"qbus");
		/*
		 * ׼����canal ���ã�������canal
		 */
		SafeService canal = new SafeService(
				new Canal(),
				"canal");
		
		stop = !canal.conn() || !qbus.conn();
		/*
		 * ��ʼ������Ϣ
		 */
		String msg;
		while (!stop) {
			try {
				msg = canal.recv();
			} catch (Exception e) {
				logger.error(e.getMessage());
				canal.reconn();
				continue;
			}
			
			if (!qbus.send(msg)) {
				logger.error("failed to send message" + msg);
			} else {
				canal.ack();
			}
		}
		canal.close();
		qbus.close();
	}
	
	public void Stop()
	{
		logger.info("shut down");
		this.stop = true;
	}

	
}
