package main;

import java.net.InetSocketAddress;

import com.alibaba.otter.canal.client.CanalConnector;
import com.alibaba.otter.canal.client.CanalConnectors;
import com.alibaba.otter.canal.protocol.Message;
import com.alibaba.otter.canal.protocol.CanalEntry.Entry;
import com.alibaba.otter.canal.common.utils.AddressUtils;

public class Canal implements Session {
	final int BATCH_NUM = 1;
	
	private long currRecordId = 0;
	
	/*
	 * canal ���
	 */
	private CanalConnector canal;
	

	public void conn() throws Exception {
		canal = CanalConnectors.newSingleConnector(new InetSocketAddress(AddressUtils.getHostIp(),
	            11111), "mysql_bin_log", "", "");
		canal.connect();
		canal.subscribe();
	}

	public void close() throws Exception
	{
		canal.disconnect();
	}

	public void send(String msg) throws Exception
	{
		throw new Exception("should not call Canal::send() method");
	}

	public String recv() throws Exception
	{
		// TODO Auto-generated method stub
		Message records = canal.getWithoutAck(BATCH_NUM);
		currRecordId = records.getId();
		for (Entry e : records.getEntries()) {
			return parseRecord(e);
		}
		return null;
	}
	
	public void ack() throws Exception
	{
		canal.ack(this.currRecordId);
	}

	private String parseRecord(Entry e)
	{
		return "";
	}
}
