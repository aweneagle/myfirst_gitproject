package main;

public interface Session {
	public void conn()throws Exception ;
	public void close()throws Exception ;
	public void send(String msg) throws Exception ;
	public String recv() throws Exception ;
	public void ack() throws Exception ;
}
