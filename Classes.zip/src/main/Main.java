package main;

import java.lang.Thread;
import java.util.ArrayList;

import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;  

public class Main {
	
	private static Logger logger;
	private static int threadNum = 4;
	private static ArrayList<MysqlQueue> threadPool;
	
    public static void main(String args[]) {
		logger = LoggerFactory.getLogger(Main.class);
    	threadPool = new ArrayList<MysqlQueue>();
    	for (int i = 0; i < threadNum; i ++) {
    		threadPool.add(new MysqlQueue());
    	}
    	for (int i = 0; i < threadNum; i ++) {
    		threadPool.get(i).Start();
    	}
    	Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                logger.info("shut down by KILL ....");
                for (int i = 0; i < threadNum; i ++) {
                	threadPool.get(i).Stop();
                }
            }
        });
    }
}
